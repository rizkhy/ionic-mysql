import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DataNilaiSiswaPage } from './data-nilai-siswa';

@NgModule({
  declarations: [
    DataNilaiSiswaPage,
  ],
  imports: [
    IonicPageModule.forChild(DataNilaiSiswaPage),
  ],
})
export class DataNilaiSiswaPageModule {}
