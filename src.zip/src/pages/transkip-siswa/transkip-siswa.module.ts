import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TranskipSiswaPage } from './transkip-siswa';

@NgModule({
  declarations: [
    TranskipSiswaPage,
  ],
  imports: [
    IonicPageModule.forChild(TranskipSiswaPage),
  ],
})
export class TranskipSiswaPageModule {}
