import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GantiPasswordSiswaPage } from './ganti-password-siswa';

@NgModule({
  declarations: [
    GantiPasswordSiswaPage,
  ],
  imports: [
    IonicPageModule.forChild(GantiPasswordSiswaPage),
  ],
})
export class GantiPasswordSiswaPageModule {}
