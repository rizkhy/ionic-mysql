import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BiodataSiswaPage } from './biodata-siswa';

@NgModule({
  declarations: [
    BiodataSiswaPage,
  ],
  imports: [
    IonicPageModule.forChild(BiodataSiswaPage),
  ],
})
export class BiodataSiswaPageModule {}
