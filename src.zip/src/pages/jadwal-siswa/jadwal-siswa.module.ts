import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JadwalSiswaPage } from './jadwal-siswa';

@NgModule({
  declarations: [
    JadwalSiswaPage,
  ],
  imports: [
    IonicPageModule.forChild(JadwalSiswaPage),
  ],
})
export class JadwalSiswaPageModule {}
