import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MengajarGuruPage } from './mengajar-guru';

@NgModule({
  declarations: [
    MengajarGuruPage,
  ],
  imports: [
    IonicPageModule.forChild(MengajarGuruPage),
  ],
})
export class MengajarGuruPageModule {}
